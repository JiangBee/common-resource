export default {
  consName: '白羊座',
  field: 'today',
  errorCode: 0,
  today: {},
  tomorrow: {},
  week: {},
  month: {},
  year: {}
}