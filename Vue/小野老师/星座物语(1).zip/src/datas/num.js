export default [
  {
    title: '健康指数',
    bgColor: '#FFFACD',
    field: 'health'
  },
  {
    title: '工作指数',
    bgColor: '#F0FFFF',
    field: 'work'
  },
  {
    title: '爱情指数',
    bgColor: '#FFF5EE',
    field: 'love'
  },
  {
    title: '财运',
    bgColor: '#FFF8DC',
    field: 'money'
  }
];