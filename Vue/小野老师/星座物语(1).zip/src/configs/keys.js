const JUHE_APPKEY = "1d74cd347b169ba4422176ad1350f3b2";
// const JUHE_APPKEY = '';

export {
  JUHE_APPKEY
}